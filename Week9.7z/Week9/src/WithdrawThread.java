import java.util.Random;
public class WithdrawThread implements Runnable
{
	private Bank bankAccount;
	private int delay;
	public WithdrawThread(Bank account,int d)
	{
		bankAccount = account;
		delay = d;
	}
	
	public void run()
	{
		Random rand = new Random();
		while(true)
		{
			int amount=rand.nextInt((50 - 30) + 1) + 30;
			System.out.printf("%d is withdraw. Bank Account Balance:%d", amount, bankAccount.withdraw(amount));
			System.out.println();
			try 
			{
				Thread.sleep(delay);
			} 
			
			catch (InterruptedException e) 
			{
				e.printStackTrace();
			}
		}
	}
}
