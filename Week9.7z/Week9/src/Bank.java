import java.util.concurrent.atomic.AtomicInteger;

class Bank 
{
    private AtomicInteger balance; 

    public Bank(int money) 
    {
        balance = new AtomicInteger(money);
    }

    public synchronized int deposit(int money)
    {
    	notifyAll();
    	return balance.addAndGet(money);
    }

    public synchronized int getBalance()
    {
    	return balance.get();
    }
    
    public synchronized int withdraw(int money)
    {
    	while(balance.get()<money)
    	{
    		try 
    		{
				wait();
				System.out.println("Waiting for withdrawing");
			} 
    		catch (InterruptedException e) 
    		{
				e.printStackTrace();
			}
    	}
    	return balance.addAndGet(-money);
    }
}