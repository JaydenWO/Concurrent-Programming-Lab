import java.util.concurrent.ArrayBlockingQueue;


public class TakeThread implements Runnable
{
	ArrayBlockingQueue queue;
	int num;
	public TakeThread(ArrayBlockingQueue queue)
	{
		this.queue = queue;
	}
	
	public void run()
	{
		while(true)
		{
			try 
			{
				num=(int) queue.take();
				System.out.printf("%d is taken\n",num);
			} 
			catch (InterruptedException e1) 
			{
				e1.printStackTrace();
			}
			
			try 
			{	
				Thread.sleep(1200);
			}
			catch (InterruptedException e) 
			{
				
			}
		}
	}
}
