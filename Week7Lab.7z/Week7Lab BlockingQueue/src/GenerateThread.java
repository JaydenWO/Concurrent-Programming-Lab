import java.util.Random;
import java.util.concurrent.ArrayBlockingQueue;
public class GenerateThread implements Runnable 
{
	ArrayBlockingQueue queue;
	Random rand = new Random();
	int num;
	
	public GenerateThread(ArrayBlockingQueue queue)
	{
		this.queue = queue;
	}
	
	public void run()
	{
		while(true)
		{
			for(int count=0;count<5;count++)
			{
				num = rand.nextInt(100)+1;
				try 
				{
					queue.put(num);
					System.out.printf("%d is queued\n",num);
				} 
				catch (InterruptedException e) 
				{
					e.printStackTrace();
				}
				
				try 
				{
					Thread.sleep(1000);
				} 
				catch (InterruptedException e) 
				{
					e.printStackTrace();
				}
			}
			
			try 
			{	
				System.out.print("Thread 1 is resting for 5 seconds\n");
				Thread.sleep(5000);
			}
			catch (InterruptedException e) 
			{
					
			}
			
		}
	}
}
