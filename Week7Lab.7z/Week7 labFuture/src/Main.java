import java.util.LinkedList;
import java.util.Random;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
//Class that use 200 threads
//200 threads is a better solution since it is faster
public class Main 
{
	public static void main(String[] args) 
	{
		double[][]array = new double[200][100];
		EvaluateThread[] myTask = new EvaluateThread[200];
		double minValue=Double.POSITIVE_INFINITY,num;
		long start=0;
		long end=0;
		ExecutorService exe = Executors.newFixedThreadPool(4);
		Random rand = new Random();
		Object array1[] = new Object[200];
		
		
		
		for(int x=0;x<200;x++)
		{
			for(int y=0;y<100;y++)
			{
				num = -5.12 + (5.12 + 5.12)* rand.nextDouble();
				array[x][y] = num;
			}
		}
		
		start = System.currentTimeMillis();
		
		for(int a=0;a<200;a++)
		{
			Future <Double> future;
			myTask[a]= new EvaluateThread(array,a);
			array1[a] = exe.submit(myTask[a]);
		}
		
		exe.shutdown();
		try
		{
			exe.awaitTermination(Long.MAX_VALUE,TimeUnit.NANOSECONDS);
		}
		catch(InterruptedException e) 
		{
			
		}
		
		for(Object future: array1)
		{
			double arrayMin = Double.POSITIVE_INFINITY;
			try 
			{
				arrayMin = ((Future <Double>)future).get();
			} catch (InterruptedException e) 
			{
				e.printStackTrace();
			} catch (ExecutionException e) 
			{
				e.printStackTrace();
			}
			if(arrayMin< minValue)
			{
				minValue = arrayMin;
			}
				
		}
		
		end =  System.currentTimeMillis();
		
		System.out.printf("The minimum value is:%.6f\n",minValue);
		System.out.printf("Time taken: %d Miliseconds", end-start);

	}

}
