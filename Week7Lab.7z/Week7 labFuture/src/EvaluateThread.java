import java.util.Random;
import java.util.concurrent.Callable;
public class EvaluateThread implements Callable<Double>
{
	double [][]array;
	double[]storeArray = new double[100];
	int row,count;
	Random rand = new Random();
	double minValue=Double.POSITIVE_INFINITY;
	public EvaluateThread(double [][]array,int row)
	{
		this.array = array;
		this.row = row;
		clone(storeArray,array[row]);
	}
	
	public Double call()throws Exception
	{
		
		double num,value=0;
		double localmin=1000000;
		
		for(int a=0;a<350;a++)
		{
			value=0;
			double min=-0.5,max=0.5;
			
			for(int z=0;z<100;z++)
			{
				value += (z+1)*(array[row][z]*array[row][z]);
			}
			
			if(localmin>value)
			{
				localmin = value;
				if(minValue>localmin)
				{
					minValue=localmin;
				}
				clone(storeArray,array[row]);
			}
			
			else
			{
				clone(array[row],storeArray);
			}
			
			for(int f=0;f<100;f++)
			{
				num = min + (max - min)* rand.nextDouble();
				if (array[row][f] + num >= -5.12 && array[row][f] + num <= 5.12)
				{
					array[row][f] += num;
					
				}
			}
			
			if(count%20==0)
			{	
				System.out.printf("Thread %d: Current minimum value is: %.6f\n",row, localmin);	
			}
		}
		return minValue;
	}
	
	/*public double getMinValue()
	{
		return minValue;
	}*/
	
	public void clone(double[]storeArray,double[]array)
	{
		for(int f=0;f<100;f++)
		{
			storeArray[f]= array[f];
		}
	}
	
		
}

