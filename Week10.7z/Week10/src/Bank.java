import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;


class Bank 
{
    private AtomicInteger balance; 
    private ReentrantLock lock =  new ReentrantLock();
    private Condition myCondition = lock.newCondition();

    public Bank(int money) 
    {
        balance = new AtomicInteger(money);
    }

    public int deposit(int money)
    {
    	lock.lock();
    	try
    	{
    		myCondition.signalAll();
    		return balance.addAndGet(money);
    	}
    	finally
    	{
    		lock.unlock();
    	}
    }

    public int getBalance()
    {

    	lock.lock();
    	try
    	{
    		myCondition.signalAll();
    		return balance.get();
    	}
    	finally
    	{
    		lock.unlock();
    	}
    	
    }
    
    public int withdraw(int money)
    {
    	lock.lock();
    	try 
		{
    		while(balance.get()<money)
    		{
    			try 
    			{
					myCondition.await();
				} 
    			catch (InterruptedException e) 
    			{
					e.printStackTrace();
				}
    			
				System.out.println("Waiting for withdrawing");
			}
    		return balance.addAndGet(-money);
		}
    	finally
    	{
    		lock.unlock();
    	}
    	
    	
    }
}