public class DepositThread implements Runnable
{
	private Bank bankAccount;
	private int amount;
	private int delay;
	public DepositThread(Bank account,int amt,int d)
	{
		bankAccount = account;
		amount = amt;
		delay = d;
	}
	
	public void run()
	{
		
		while(true)
		{
			System.out.printf("\n%d is deposited. Bank Account Balance:%d", amount, bankAccount.deposit(amount));
			System.out.println();
			try 
			{
				Thread.sleep(delay);
			} 
			catch (InterruptedException e) 
			{
				e.printStackTrace();
			}
		}
	}
}
