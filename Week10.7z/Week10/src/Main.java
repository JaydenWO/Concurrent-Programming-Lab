
public class Main {

	public static void main(String[] args)
	{
		Bank bankAccount = new Bank(100);
		DepositThread deposit1 = new DepositThread(bankAccount,10,2000);
		DepositThread deposit2 = new DepositThread(bankAccount,20,1500);
		WithdrawThread withdraw = new WithdrawThread(bankAccount,1000);
		
		Thread t1 = new Thread(deposit1);
		Thread t2 = new Thread(deposit2);
		Thread t3 = new Thread(withdraw);
		
		t1.start();
		t2.start();
		t3.start();

	}

}
